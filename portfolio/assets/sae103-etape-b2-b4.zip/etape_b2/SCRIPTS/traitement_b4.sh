#!/bin/bash
chmod -R 777 data 2>/dev/null
mkdir -p data

for excel in data/*.xlsx; do
    if [ -f "$excel" ]; then
        nom=$(basename "$excel")
        docker container run --rm --network none -v "$(pwd)/data:/work" --entrypoint ssconvert bigpapoo/sae103-excel2csv:1.0 /work/"$nom" /work/"${nom%.xlsx}.csv"
    fi
done

for img in data/*.jpg data/*.png; do
    if [ -f "$img" ]; then
        nom=$(basename "$img")
        docker container run --rm --network none -v "$(pwd)/data:/work" --entrypoint convert bigpapoo/sae103-imagick:1.0 /work/"$nom" -resize 900x620 /work/"${nom%.*}.webp"
    fi
done

if [ -f data/texte.txt ]; then
    grep -v '^$' data/texte.txt > data/texte_clean.txt
    bash script_txt.sh data/texte_clean.txt
fi

docker container run --rm --network none -v "$(pwd):/work" bigpapoo/sae103-php:1.0 php /work/index_b4.php > data/resultat.html
docker container run --rm --network none -v "$(pwd)/data:/data" bigpapoo/sae103-html2pdf:1.0 weasyprint /data/resultat.html /data/rapport.pdf
chmod -R 777 data 2>/dev/null
