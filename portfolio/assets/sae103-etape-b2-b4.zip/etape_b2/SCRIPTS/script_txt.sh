#!/bin/bash
fichier=$1
type_bloc=""
titre=""
texte=""
num_sect=0
num_sous=0
while read ligne; do
    if [[ $ligne == TITLE=* || $ligne == SECT=* || $ligne == SUB_SECT=* ]]; then
        if [[ -n $type_bloc ]]; then
            if [[ $type_bloc == TITLE ]]; then echo "$titre" > data/TITLE.txt
            elif [[ $type_bloc == SECT ]]; then echo -e "$titre\n$texte" > "data/SECT${num_sect}.txt"
            elif [[ $type_bloc == SUB_SECT ]]; then echo -e "$titre\n$texte" > "data/SUB_SECT${num_sect}${num_sous}.txt"
            fi
        fi
        texte=""
        if [[ $ligne == TITLE=* ]]; then type_bloc="TITLE"; titre="${ligne#TITLE=}"
        elif [[ $ligne == SECT=* ]]; then num_sect=$((num_sect+1)); num_sous=0; type_bloc="SECT"; titre="${ligne#SECT=}"
        elif [[ $ligne == SUB_SECT=* ]]; then num_sous=$((num_sous+1)); type_bloc="SUB_SECT"; titre="${ligne#SUB_SECT=}"
        fi
    elif [[ $ligne == TEXT=* ]]; then texte+="${ligne#TEXT=}"$'\n'
    fi
done < "$fichier"
if [[ -n $type_bloc ]]; then
    if [[ $type_bloc == TITLE ]]; then echo "$titre" > data/TITLE.txt
    elif [[ $type_bloc == SECT ]]; then echo -e "$titre\n$texte" > "data/SECT${num_sect}.txt"
    elif [[ $type_bloc == SUB_SECT ]]; then echo -e "$titre\n$texte" > "data/SUB_SECT${num_sect}${num_sous}.txt"
    fi
fi
