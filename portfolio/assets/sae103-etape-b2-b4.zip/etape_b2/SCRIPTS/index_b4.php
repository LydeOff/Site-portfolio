<?php
echo "<h1>Rapport Touristique - Equipe b4</h1>";
$fichiers = scandir("data");
foreach ($fichiers as $f) {
    $ext = pathinfo($f, PATHINFO_EXTENSION);
    if ($ext == "csv") {
        echo "<h2>Tableau : $f</h2><table border='1'>";
        $handle = fopen("data/" . $f, "r");
        while (($ligne = fgetcsv($handle)) !== FALSE) {
            echo "<tr>";
            foreach ($ligne as $cellule) echo "<td>" . htmlspecialchars($cellule) . "</td>";
            echo "</tr>";
        }
        fclose($handle);
        echo "</table>";
    }
    if ($ext == "webp") {
        echo "<h3>Image : $f</h3><img src='$f' width='400'><br>";
    }
}
?>
