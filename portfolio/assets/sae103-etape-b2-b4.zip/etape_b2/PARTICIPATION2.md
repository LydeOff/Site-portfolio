# PARTICIPATION MEMBRES EQUIPE B4

## TABLEAU DE SYNTHESE JEU DE FICHIERS

Temps total : XX H (ou YY min)

| Membre   | %   | Commentaire |
| ------   | --- | ----------- |
| Dylan    | 33  |   3H30      |
| Thomas   | 33  |   3H30      |
| Karim    | 33  |   3H30        |

## TACHE ZZZ

Partie 1 :

Dylan conversion de tous les fichiers via docker + remplissage tableau etape_a1
Karim tableau etape_a1
Thomas création des documents txt à partir du fichier presentation_musee_louvre

Partie 2 :

Dylan Création script pour DEPTS et REGION
Karim Création script pour Images et Tableau excel + script général
Thomas Création script pour HTML
