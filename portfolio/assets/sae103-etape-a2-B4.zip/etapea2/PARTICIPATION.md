# PARTICIPATION MEMBRES EQUIPE B4

## TABLEAU DE SYNTHESE JEU DE FICHIERS

Temps total : XX H (ou YY min)

| Membre   | %   | Commentaire |
| ------   | --- | ----------- |
| Dylan    | 50  |   3H30      |
| Thomas   | 30  |   1H30      |
| Karim    | 20  |   1H        |

## TACHE ZZZ

Dylan conversion de tous les fichiers via docker + remplissage tableau etape_a1
Karim tableau etape_a1
Thomas création des documents txt à partir du fichier presentation_musee_louvre
