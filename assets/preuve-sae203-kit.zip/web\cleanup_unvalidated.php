<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

$link = db_connect();
$sql = 'DELETE FROM users WHERE is_validated = 0';

if (!mysqli_query($link, $sql)) {
    fwrite(STDERR, 'Erreur nettoyage: ' . mysqli_error($link) . PHP_EOL);
    exit(1);
}

echo date('c') . ' - comptes non valides supprimes: ' . mysqli_affected_rows($link) . PHP_EOL;
?>
