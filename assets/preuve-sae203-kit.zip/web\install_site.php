<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

$link = db_connect(false);
mysqli_query($link, 'CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
mysqli_select_db($link, DB_NAME);

$createUsers = <<<SQL
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(80) NOT NULL,
    prenom VARCHAR(80) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    login VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    validation_token VARCHAR(128) DEFAULT NULL,
    is_validated TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;

if (!mysqli_query($link, $createUsers)) {
    die('Erreur creation table users: ' . mysqli_error($link));
}

$seedUsers = [
    ['Durand', 'Alice', 'alice@example.local', 'alice'],
    ['Martin', 'Bob', 'bob@example.local', 'bob'],
    ['Bernard', 'Charlie', 'charlie@example.local', 'charlie'],
];

$stmt = mysqli_prepare(
    $link,
    'INSERT INTO users (nom, prenom, email, login, password_hash, is_validated)
     VALUES (?, ?, ?, ?, ?, 1)
     ON DUPLICATE KEY UPDATE nom = VALUES(nom), prenom = VALUES(prenom), is_validated = 1'
);

foreach ($seedUsers as [$nom, $prenom, $email, $login]) {
    $hash = password_hash('lannion', PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, 'sssss', $nom, $prenom, $email, $login, $hash);
    mysqli_stmt_execute($stmt);
}

?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Installation SAE 2.03</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Installation terminee</h1>
    <p>La base de donnees du site SAE 2.03 est prete.</p>
    <nav>
        <a href="/">Accueil</a>
        <a href="/login.php">Connexion</a>
        <a href="/register.php">Inscription</a>
    </nav>
</header>
<main>
    <section>
        <p class="message">Base <code><?= htmlspecialchars(DB_NAME) ?></code> creee avec la table <code>users</code>.</p>
        <p>Comptes de test valides: <code>alice</code>, <code>bob</code>, <code>charlie</code>. Mot de passe: <code>lannion</code>.</p>
    </section>
</main>
</body>
</html>
