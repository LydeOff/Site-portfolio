<?php
declare(strict_types=1);

$link = mysqli_connect('localhost', 'root', 'lannion');

if (!$link) {
    die('Erreur connexion MySQL: ' . mysqli_connect_error() . PHP_EOL);
}

$queries = [
    'CREATE DATABASE IF NOT EXISTS buani',
    'USE buani',
    'DROP TABLE IF EXISTS etudiants',
    "CREATE TABLE etudiants (
        id INT PRIMARY KEY NOT NULL,
        nom VARCHAR(40),
        date_naissance DATE,
        classement INT
    )",
    "INSERT INTO etudiants (id, nom, date_naissance, classement) VALUES
        (1, 'Dupont', '2005-02-15', 2),
        (2, 'Martin', '2004-09-21', 1),
        (3, 'Bernard', '2005-12-03', 3)",
    'DELETE FROM etudiants WHERE id = 3',
    "UPDATE etudiants
        SET date_naissance = '1990-01-01'
        WHERE id = (SELECT min_id FROM (SELECT MIN(id) AS min_id FROM etudiants) AS tmp)"
];

foreach ($queries as $sql) {
    if (!mysqli_query($link, $sql)) {
        die('Erreur SQL: ' . mysqli_error($link) . PHP_EOL);
    }
}

$result = mysqli_query($link, 'SELECT * FROM etudiants');

echo "<pre>\n";
while ($row = mysqli_fetch_assoc($result)) {
    print_r($row);
}
echo "</pre>\n";
?>
