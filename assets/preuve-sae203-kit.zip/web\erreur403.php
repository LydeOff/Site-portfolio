<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Acces interdit</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Erreur 403</h1>
    <p>Vous n'avez pas le droit d'acceder a cette ressource.</p>
    <nav>
        <a href="/">Retour accueil</a>
    </nav>
</header>
<main>
    <section>
        <p>Cette page d'erreur est personnalisee pour le serveur SAE 2.03.</p>
    </section>
</main>
</body>
</html>
