<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

$token = $_GET['token'] ?? '';
$message = '';
$error = '';

if ($token === '') {
    $error = 'Token manquant.';
} else {
    $link = db_connect();
    $stmt = mysqli_prepare($link, 'UPDATE users SET is_validated = 1, validation_token = NULL WHERE validation_token = ?');
    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) === 1) {
        $message = 'Compte valide. Vous pouvez maintenant vous connecter.';
    } else {
        $error = 'Lien invalide ou deja utilise.';
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Validation compte</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Validation</h1>
    <nav>
        <a href="/">Accueil</a>
        <a href="/login.php">Connexion</a>
    </nav>
</header>
<main>
    <section>
        <?php if ($message): ?><p class="message"><?= htmlspecialchars($message) ?></p><?php endif; ?>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    </section>
</main>
</body>
</html>
