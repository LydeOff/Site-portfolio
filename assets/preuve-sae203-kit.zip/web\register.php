<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

$message = '';
$error = '';
$validationLink = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($nom === '' || $prenom === '' || $email === '' || $login === '' || $password === '') {
        $error = 'Tous les champs sont obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Adresse email invalide.';
    } else {
        $link = db_connect();
        $check = mysqli_prepare($link, 'SELECT id FROM users WHERE email = ? OR login = ?');
        mysqli_stmt_bind_param($check, 'ss', $email, $login);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if (mysqli_stmt_num_rows($check) > 0) {
            $error = 'Login ou email deja utilise.';
        } else {
            $token = bin2hex(random_bytes(32));
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare(
                $link,
                'INSERT INTO users (nom, prenom, email, login, password_hash, validation_token, is_validated)
                 VALUES (?, ?, ?, ?, ?, ?, 0)'
            );
            mysqli_stmt_bind_param($stmt, 'ssssss', $nom, $prenom, $email, $login, $hash, $token);

            if (mysqli_stmt_execute($stmt)) {
                $validationLink = 'http://' . ($_SERVER['HTTP_HOST'] ?? '127.0.0.1') . '/validate.php?token=' . $token;
                $message = 'Compte cree. Pour la SAE, le lien de validation est affiche ici au lieu d etre envoye par mail.';
            } else {
                $error = 'Erreur inscription: ' . mysqli_error($link);
            }
        }
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Inscription utilisateur</h1>
    <p>Creation d'un compte avec validation par lien aleatoire.</p>
    <nav>
        <a href="/">Accueil</a>
        <a href="/login.php">Connexion</a>
    </nav>
</header>
<main>
    <section>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <?php if ($message): ?><p class="message"><?= htmlspecialchars($message) ?></p><?php endif; ?>
        <?php if ($validationLink): ?>
            <p>Lien de validation:</p>
            <pre><?= htmlspecialchars($validationLink) ?></pre>
        <?php endif; ?>

        <form method="post">
            <label>Nom <input name="nom" required></label>
            <label>Prenom <input name="prenom" required></label>
            <label>Email <input name="email" type="email" required></label>
            <label>Login <input name="login" required></label>
            <label>Mot de passe <input name="password" type="password" required></label>
            <button class="button" type="submit">Creer le compte</button>
        </form>
    </section>
</main>
</body>
</html>
