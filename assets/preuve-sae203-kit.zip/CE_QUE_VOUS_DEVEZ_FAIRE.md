# SAE 2.03 - Ce que vous devez faire

## Peut-on faire toute la SAE directement ?

Je peux preparer le code, les commandes, les configurations et le rapport-guide.
Par contre, la SAE doit etre executee dans votre VM Debian: c'est la que vous
devez lancer les commandes et faire les captures d'ecran. Ces captures prouvent
que le serveur marche vraiment sur votre machine.

## Ordre conseille

### 1. Demarrer la VM

Connectez-vous avec:

```text
root / lannion
```

Verifiez les versions:

```bash
cat /etc/debian_version
apache2 -v
php -v
mysql -V
```

Capture: versions.

### 2. Partie Apache

Commandes principales:

```bash
systemctl status apache2
grep -R "DocumentRoot" /etc/apache2/sites-enabled /etc/apache2/sites-available
type -a apache2
apache2 -l
apache2 -M
apache2 -v
apache2 --version
```

Si `apache2 --version` affiche un warning, ajoutez dans `/etc/apache2/apache2.conf`:

```apache
ServerName localhost
```

Puis:

```bash
systemctl restart apache2
```

### 3. Partie admin privee Apache

Copiez le site:

```bash
cp -r /mnt/hgfs/VOTRE_DOSSIER/SAE203_kit/web/* /var/www/html/
```

Ajoutez la configuration de:

```text
SAE203_kit/apache/apache2.conf-additions.conf
```

dans:

```text
/etc/apache2/apache2.conf
```

Creez le compte:

```bash
htpasswd -c /etc/apache2/pass admin
```

Mot de passe: `lannion`.

Puis:

```bash
systemctl restart apache2
```

Capture: acces a `/private/`, demande login/mot de passe, page affichee apres connexion.

### 4. Partie PHP

Testez:

```text
http://127.0.0.1/secret-sae203/phpinfo.php
```

Relevez dans la page:

- version PHP
- dossier de configuration PHP
- fichier `php.ini`
- valeur de `short_open_tag`

Desactivez/reactivez PHP pour le TP:

```bash
a2dismod php7.4
systemctl restart apache2
a2enmod php7.4
systemctl restart apache2
```

Capture: module absent/present dans `/etc/apache2/mods-enabled`.

### 5. PHP dans HTML et fichiers sans extension

Modifiez:

```text
/etc/apache2/mods-available/php7.4.conf
```

Ajoutez les changements expliques dans:

```text
README_INSTALLATION.md
```

Testez:

```text
http://127.0.0.1/mapage.html
http://127.0.0.1/phpinfo
```

### 6. Partie MySQL

Securisez MySQL:

```bash
mysql_secure_installation
```

Gardez le mot de passe root `lannion`, puis repondez oui aux nettoyages de securite.

Statut et version:

```bash
systemctl status mysql
mysql -V
```

Connexion:

```bash
mysql -u root -p
```

Puis:

```sql
SHOW DATABASES;
```

### 7. Exercices SQL du TP

Utilisez:

```text
SAE203_kit/scripts/exercice_mysql.sql
```

Important: si votre enseignant veut absolument une base portant votre prenom,
remplacez `buani` par votre prenom dans le script avant execution.

### 8. Afficher les bases MySQL avec PHP

Testez:

```text
http://127.0.0.1/showdb.php
```

Si erreur `mysqli_connect`, installez les paquets PHP MySQL depuis `/usr/local/src`:

```bash
cd /usr/local/src
dpkg -i *.deb
systemctl restart apache2
```

### 9. Cahier des charges bonus du TD

Le kit contient deja:

- page publique dynamique: `/`
- admin Apache: `/private/`
- connexion par base MySQL: `/login.php`
- inscription: `/register.php`
- validation par lien aleatoire: `/validate.php`
- session PHP: `/dashboard.php`
- erreurs personnalisees: `/erreur404.php`, `/erreur403.php`
- nettoyage cron: `/cleanup_unvalidated.php`

Installez la base du site:

```text
http://127.0.0.1/install_site.php
```

Comptes de test:

```text
alice / lannion
bob / lannion
charlie / lannion
```

Cron:

```bash
crontab -e
```

Ajouter:

```cron
0 3 * * * /usr/bin/php /var/www/html/cleanup_unvalidated.php >> /var/log/sae203-cleanup.log 2>&1
```

### 10. Rapport PDF

Utilisez:

```text
SAE203_kit/rapport/rapport_SAE203_a_completer.md
```

Dans le PDF final, mettez:

- page de garde avec noms et groupe
- fiche de suivi remplie
- reponses aux questions TP
- commandes utilisees
- captures d'ecran personnelles
- partie cahier des charges si vous faites le bonus

Ne recopiez pas l'exemple ABAZI tel quel: utilisez vos captures et vos valeurs.
