# SAE 2.03 - Kit de realisation

Ce dossier contient un kit pret a copier dans la VM Debian de la SAE 2.03.
Il ne remplace pas vos captures d'ecran: pour le rapport, il faut lancer les
commandes dans la VM et coller vos propres resultats.

## 1. Copier le site dans Apache

Dans la VM, copiez le contenu du dossier `web` vers la racine Apache:

```bash
cp -r /mnt/hgfs/VOTRE_DOSSIER/SAE203_kit/web/* /var/www/html/
chown -R www-data:www-data /var/www/html
find /var/www/html -type d -exec chmod 755 {} \;
find /var/www/html -type f -exec chmod 644 {} \;
```

Remplacez `/mnt/hgfs/VOTRE_DOSSIER` par le chemin de votre dossier partage
VMware.

## 2. Sauvegarder les fichiers de configuration avant modification

```bash
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.old
cp /etc/apache2/mods-available/php7.4.conf /etc/apache2/mods-available/php7.4.conf.old
cp /etc/php/7.4/apache2/php.ini /etc/php/7.4/apache2/php.ini.old
```

## 3. Configuration Apache obligatoire

Ajoutez le contenu de `apache/apache2.conf-additions.conf` a la fin de:

```bash
nano /etc/apache2/apache2.conf
```

Puis creez le compte admin Apache:

```bash
htpasswd -c /etc/apache2/pass admin
```

Mot de passe demande: `lannion`.

Rechargez Apache:

```bash
systemctl restart apache2
systemctl status apache2
```

Test:

```text
http://127.0.0.1/
http://127.0.0.1/private/
```

## 4. Configuration PHP demandee par le TP

Pour interpreter du PHP dans les fichiers `.html`, modifiez:

```bash
nano /etc/apache2/mods-available/php7.4.conf
```

Remplacez la ligne:

```apache
<FilesMatch ".+\.ph(ar|p|tml)$">
```

par:

```apache
<FilesMatch ".+\.html?$|.+\.ph(ar|p|tml)$">
```

Pour interpreter les fichiers sans extension, ajoutez ensuite:

```apache
<FilesMatch "^[^.]+$">
    SetHandler application/x-httpd-php
</FilesMatch>
```

Pour activer la syntaxe courte `<? ... ?>`, modifiez:

```bash
nano /etc/php/7.4/apache2/php.ini
```

Cherchez `short_open_tag` et mettez:

```ini
short_open_tag = On
```

Rechargez Apache:

```bash
systemctl restart apache2
```

## 5. Installer le module PHP MySQL si mysqli manque

Dans la VM de la SAE, les paquets sont normalement dans `/usr/local/src`.
Installez-les seulement au moment demande dans le TP:

```bash
cd /usr/local/src
dpkg -i *.deb
systemctl restart apache2
```

L'erreur typique avant installation est:

```text
Call to undefined function mysqli_connect()
```

## 6. Installer la base du site bonus

Ouvrez dans le navigateur:

```text
http://127.0.0.1/install_site.php
```

Cela cree une base `sae203_site`, une table `users`, et 3 comptes valides:

```text
alice / lannion
bob / lannion
charlie / lannion
```

Ensuite testez:

```text
http://127.0.0.1/login.php
http://127.0.0.1/register.php
```

## 7. Cron pour supprimer les comptes non valides a 3h

Ouvrez la crontab root:

```bash
crontab -e
```

Ajoutez:

```cron
0 3 * * * /usr/bin/php /var/www/html/cleanup_unvalidated.php >> /var/log/sae203-cleanup.log 2>&1
```

## 8. Exercices SQL obligatoires

Les commandes SQL du TP sont dans:

```text
scripts/exercice_mysql.sql
```

Vous pouvez les executer a la main dans `mysql`, ou avec:

```bash
mysql -u root -p < /mnt/hgfs/VOTRE_DOSSIER/SAE203_kit/scripts/exercice_mysql.sql
```

Mot de passe MySQL: `lannion`.

## 9. Rapport

Le rapport-guide est ici:

```text
rapport/rapport_SAE203_a_completer.md
```

Gardez les reponses, remplacez les valeurs variables par celles de votre VM,
et ajoutez vos captures d'ecran.
