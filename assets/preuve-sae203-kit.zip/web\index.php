<?php
declare(strict_types=1);

$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'inconnu';
$isMobile = preg_match('/Mobile|Android|iPhone|iPad/i', $userAgent) === 1;
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'inconnu';
$serverName = $_SERVER['SERVER_SOFTWARE'] ?? 'Apache';
$date = date('d/m/Y H:i:s');
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>SAE 2.03 - Accueil</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>SAE 2.03 - Serveur Web dynamique</h1>
    <p>Apache, PHP et MySQL sur Debian.</p>
    <nav>
        <a href="/">Accueil</a>
        <a href="/mapage.html">PHP dans HTML</a>
        <a href="/secret-sae203/phpinfo.php">phpinfo</a>
        <a href="/showdb.php">Bases MySQL</a>
        <a href="/private/">Administration Apache</a>
        <a href="/login.php">Espace utilisateur</a>
        <a href="/register.php">Inscription</a>
    </nav>
</header>

<main>
    <section>
        <h2>Informations dynamiques</h2>
        <div class="grid">
            <div class="stat">
                <strong>Date cote serveur</strong>
                <?= htmlspecialchars($date) ?>
            </div>
            <div class="stat">
                <strong>Adresse IP cliente</strong>
                <?= htmlspecialchars($clientIp) ?>
            </div>
            <div class="stat">
                <strong>Terminal detecte</strong>
                <?= $isMobile ? 'Mobile ou tablette' : 'Ordinateur' ?>
            </div>
            <div class="stat">
                <strong>Serveur</strong>
                <?= htmlspecialchars($serverName) ?>
            </div>
        </div>
    </section>

    <section>
        <h2>Objectif du site</h2>
        <p>
            Cette page publique montre que le serveur interprete du PHP et
            affiche un contenu qui change selon la date, le navigateur et le
            client qui se connecte.
        </p>
    </section>
</main>

<footer>SAE 2.03 - Installation de services reseau</footer>
</body>
</html>
