<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = 'lannion';
const DB_NAME = 'sae203_site';

function db_connect(bool $withDatabase = true): mysqli
{
    $database = $withDatabase ? DB_NAME : '';
    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASS, $database);

    if (!$link) {
        die('Erreur de connexion MySQL: ' . mysqli_connect_error());
    }

    mysqli_set_charset($link, 'utf8mb4');
    return $link;
}

function require_login(): void
{
    session_start();

    if (empty($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
}
?>
