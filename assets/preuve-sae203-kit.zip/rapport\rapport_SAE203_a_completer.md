# SAE 2.03 - Installation de services reseau

Noms du groupe:

- Nom Prenom 1 - chef de projet
- Nom Prenom 2 - chef-adjoint
- Nom Prenom 3 - membre
- Nom Prenom 4 - membre, si besoin

Demi-groupe TP:

## Fiche de suivi

Inserer ici la fiche de suivi remplie: composition, presences, avancement par seance.

## Sommaire

1. Partie Apache
2. Partie PHP
3. Partie MySQL et PHP
4. Cahier de charge du site

## Partie Apache

### 1. Environnement pratique

Nous avons utilise la VM Debian 11 fournie pour la SAE, avec Apache, PHP et MySQL.

Commandes utiles pour relever les versions:

```bash
cat /etc/debian_version
apache2 -v
php -v
mysql -V
```

Capture a inserer: versions exactes de Debian, Apache, PHP et MySQL.

### 2. Statut du service Apache

Commande:

```bash
systemctl status apache2
```

Informations a relever: `active (running)`, PID principal, date/heure de demarrage.

### 3. Directive DocumentRoot

Commande:

```bash
grep -R "DocumentRoot" /etc/apache2/sites-enabled /etc/apache2/sites-available
```

Fichier attendu sur Debian:

```text
/etc/apache2/sites-available/000-default.conf
```

Valeur par defaut:

```text
/var/www/html
```

Role: `DocumentRoot` indique le repertoire depuis lequel Apache sert les pages Web.

### 4. Chemin du binaire Apache

Commande:

```bash
type -a apache2
```

Chemin attendu:

```text
/usr/sbin/apache2
```

### 5. Version Apache

Commande:

```bash
apache2 -v
```

Connaitre la version exacte sert a verifier la compatibilite des modules, la documentation
adaptee et les failles de securite corrigees.

### 6. Modules natifs

Commande:

```bash
apache2 -l
```

Capture a inserer: liste des modules compiles statiquement.

### 7. Role de mod_log_config.c

Le module `mod_log_config.c` gere la personnalisation du format des logs Apache,
notamment les journaux d'acces.

### 8. Modules charges

Commande:

```bash
apache2 -M
```

ou:

```bash
apachectl -M
```

Capture a inserer: liste des modules statiques et dynamiques.

### 9. Difference entre apache2 -v et apache2 --version

Commandes:

```bash
apache2 -v
apache2 --version
```

Si `apache2 --version` affiche un avertissement sur le nom du serveur, ajouter:

```apache
ServerName localhost
```

dans:

```text
/etc/apache2/apache2.conf
```

Puis redemarrer:

```bash
systemctl restart apache2
```

### Partie administration privee

Creation du dossier:

```bash
mkdir /var/www/html/private
nano /var/www/html/private/index.html
```

Creation du compte Apache:

```bash
htpasswd -c /etc/apache2/pass admin
```

Mot de passe: `lannion`.

Configuration ajoutee dans `/etc/apache2/apache2.conf`:

```apache
<Directory "/var/www/html/private">
    AuthType Basic
    AuthName "Espace administration SAE 2.03"
    AuthUserFile "/etc/apache2/pass"
    Require valid-user
</Directory>
```

Redemarrage:

```bash
systemctl restart apache2
```

Test: acceder a `http://127.0.0.1/private/`.

Captures a inserer: demande login/mot de passe, puis page privee affichee.

## Partie PHP

### 1. Creation de phpinfo

Fichier:

```text
/var/www/html/secret-sae203/phpinfo.php
```

Code:

```php
<?php phpinfo(); ?>
```

### 2. Pourquoi un dossier secret ?

`phpinfo()` affiche des informations sensibles: version PHP, modules, chemins de
configuration. Le placer dans un dossier non evident limite les acces accidentels.

### 3. URL du script

URL locale:

```text
http://127.0.0.1/secret-sae203/phpinfo.php
```

### 4. Confirmation que PHP est actif

Si la page affiche le tableau `phpinfo()` au lieu du code source, Apache interprete
bien le PHP.

### 5. Verification du module PHP

Commandes:

```bash
ls /etc/apache2/mods-enabled | grep php
ls -l /etc/apache2/mods-enabled/php7.4.conf
cat /etc/apache2/mods-enabled/php7.4.conf
```

Le fichier dans `mods-enabled` est normalement un lien symbolique vers
`/etc/apache2/mods-available/php7.4.conf`.

### 6. Informations phpinfo

Informations a relever:

- Version PHP: visible dans `phpinfo()`
- Dossier de configuration: `Loaded Configuration File`
- Fichier de configuration: souvent `/etc/php/7.4/apache2/php.ini`
- `short_open_tag`: valeur locale et master

Pour modifier `short_open_tag`:

```bash
nano /etc/php/7.4/apache2/php.ini
systemctl restart apache2
```

### 7. Chemin du binaire PHP

Commandes:

```bash
whereis php
php -v
```

### 8 a 11. Desactivation et reactivation PHP

Desactiver:

```bash
a2dismod php7.4
systemctl restart apache2
```

Tests:

```bash
ls /etc/apache2/mods-enabled | grep php
```

et acceder a `phpinfo.php`. Si PHP est desactive, le serveur ne doit plus
interpreter correctement le fichier PHP.

Reactiver:

```bash
a2enmod php7.4
systemctl restart apache2
```

Refaire les deux tests.

### 12 a 15. PHP dans une page HTML

Fichier:

```text
/var/www/html/mapage.html
```

Code de test:

```php
<?php echo "coucou, je suis un code php dans une page HTML !"; ?>
```

Par defaut, Apache n'interprete pas PHP dans `.html`, car le handler PHP vise
les fichiers `.php`, `.phtml` et `.phar`.

Modification dans:

```text
/etc/apache2/mods-available/php7.4.conf
```

Remplacer:

```apache
<FilesMatch ".+\.ph(ar|p|tml)$">
```

par:

```apache
<FilesMatch ".+\.html?$|.+\.ph(ar|p|tml)$">
```

Puis:

```bash
systemctl restart apache2
```

### 16 et 17. Fichier PHP sans extension

Dupliquer:

```bash
cp /var/www/html/secret-sae203/phpinfo.php /var/www/html/phpinfo
```

Ajouter dans `/etc/apache2/mods-available/php7.4.conf`:

```apache
<FilesMatch "^[^.]+$">
    SetHandler application/x-httpd-php
</FilesMatch>
```

Puis:

```bash
systemctl restart apache2
```

Test: `http://127.0.0.1/phpinfo`.

### 18. short_open_tag

Dans `mapage.html`, remplacer:

```php
<?php echo "texte"; ?>
```

par:

```php
<? echo "texte"; ?>
```

Si cela ne fonctionne pas, activer dans `/etc/php/7.4/apache2/php.ini`:

```ini
short_open_tag = On
```

Puis redemarrer Apache.

## Partie MySQL et PHP

### 1. Securisation MySQL

Commande:

```bash
mysql_secure_installation
```

Reponses conseillees:

- VALIDATE PASSWORD: selon la consigne enseignant, souvent `n` pour garder `lannion`
- Change root password: `n`, car le TP demande de garder `lannion`
- Remove anonymous users: `Y`
- Disallow root login remotely: `Y`
- Remove test database: `Y`
- Reload privilege tables: `Y`

### 2. Statut MySQL

Commande:

```bash
systemctl status mysql
```

Relever: `active (running)` et l'heure de demarrage.

### 3. Version MySQL

Commande:

```bash
mysql -V
```

### 4. Connexion MySQL

Commande:

```bash
mysql -u root -p
```

Mot de passe: `lannion`.

### 5. Afficher les bases

Requete SQL:

```sql
SHOW DATABASES;
```

### 6. Meme resultat avec PHP

Script fourni:

```text
/var/www/html/showdb.php
```

Il utilise:

```php
mysqli_connect('localhost', 'root', 'lannion')
mysqli_query($link, 'SHOW DATABASES')
```

Si l'erreur `Call to undefined function mysqli_connect()` apparait, le module
PHP MySQL n'est pas installe ou pas charge.

Correction:

```bash
cd /usr/local/src
dpkg -i *.deb
systemctl restart apache2
```

### 7 a 10. Base, table, insertion, suppression, modification

Les requetes sont fournies dans:

```text
scripts/exercice_mysql.sql
```

Points importants:

```sql
CREATE DATABASE buani;
CREATE TABLE etudiants (
    id INT PRIMARY KEY NOT NULL,
    nom VARCHAR(40),
    date_naissance DATE,
    classement INT
);
INSERT INTO etudiants VALUES (...);
DELETE FROM etudiants WHERE id = 3;
UPDATE etudiants SET date_naissance = '1990-01-01' WHERE id = ...;
```

### 11. Meme manipulation avec PHP

Script fourni:

```text
scripts/exercice_mysql_php.php
```

Copier ce script dans `/var/www/html/` puis tester par navigateur.

## Cahier de charge du site

Elements realises dans le kit:

- Pages publiques avec navigation.
- Informations dynamiques: date, IP cliente, type de terminal, serveur.
- Espace admin protege par Apache: `/private/`.
- Authentification utilisateur par PHP et MySQL: `/login.php`.
- Inscription avec unicite du login et du mail: `/register.php`.
- Lien de validation aleatoire: `/validate.php?token=...`.
- Refus de connexion si compte non valide.
- Session PHP pour ne pas redemander le mot de passe a chaque page.
- Pages d'erreur personnalisees 404 et 403.
- Nettoyage quotidien des comptes non valides par cron.

Captures conseillees:

- Accueil public.
- Page admin demandant login/mot de passe.
- Table `users` dans MySQL.
- Inscription avec lien de validation.
- Connexion refusee avant validation.
- Connexion reussie apres validation.
- Crontab contenant la ligne de nettoyage.

## Conclusion

Cette SAE nous a permis de configurer un serveur Apache, d'activer et parametrer
PHP, de connecter PHP a MySQL, puis de deployer un site dynamique avec une
partie publique, une zone admin protegee par Apache et une zone utilisateur
protegee par une base de donnees.
