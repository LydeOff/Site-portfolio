<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Page introuvable</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Erreur 404</h1>
    <p>La page demandee n'existe pas sur ce serveur.</p>
    <nav>
        <a href="/">Retour accueil</a>
    </nav>
</header>
<main>
    <section>
        <p>Cette page d'erreur est personnalisee pour remplacer la page Apache par defaut.</p>
    </section>
</main>
</body>
</html>
