<?php
declare(strict_types=1);

require __DIR__ . '/db.php';
require_login();
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Espace utilisateur</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Espace utilisateur</h1>
    <p>Page accessible seulement si la session PHP est active.</p>
    <nav>
        <a href="/">Accueil</a>
        <a href="/logout.php">Deconnexion</a>
    </nav>
</header>
<main>
    <section>
        <p class="message">Bienvenue <?= htmlspecialchars($_SESSION['login'] ?? 'utilisateur') ?>.</p>
        <p>Cette page verifie la session avant d'afficher son contenu.</p>
    </section>
</main>
</body>
</html>
