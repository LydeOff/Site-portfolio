<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $link = db_connect();
    $stmt = mysqli_prepare($link, 'SELECT id, login, password_hash, is_validated FROM users WHERE login = ?');
    mysqli_stmt_bind_param($stmt, 's', $login);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if (!$user || !password_verify($password, $user['password_hash'])) {
        $error = 'Login ou mot de passe incorrect.';
    } elseif ((int)$user['is_validated'] !== 1) {
        $error = 'Compte non valide. Cliquez d abord sur le lien de validation.';
    } else {
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['login'] = $user['login'];
        header('Location: /dashboard.php');
        exit;
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Connexion utilisateur</h1>
    <p>Authentification geree par PHP et MySQL.</p>
    <nav>
        <a href="/">Accueil</a>
        <a href="/register.php">Inscription</a>
    </nav>
</header>
<main>
    <section>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <form method="post">
            <label>Login <input name="login" required></label>
            <label>Mot de passe <input name="password" type="password" required></label>
            <button class="button" type="submit">Se connecter</button>
        </form>
    </section>
</main>
</body>
</html>
