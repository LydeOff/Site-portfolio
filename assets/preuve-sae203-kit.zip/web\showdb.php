<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

$link = db_connect(false);
$result = mysqli_query($link, 'SHOW DATABASES');
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Liste des bases MySQL</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>MySQL depuis PHP</h1>
    <p>Execution de la requete SQL <code>SHOW DATABASES</code>.</p>
    <nav>
        <a href="/">Accueil</a>
    </nav>
</header>
<main>
    <section>
        <h2>Bases detectees</h2>
        <?php if (!$result): ?>
            <p class="error">Erreur SQL: <?= htmlspecialchars(mysqli_error($link)) ?></p>
        <?php else: ?>
            <ul>
                <?php while ($row = mysqli_fetch_row($result)): ?>
                    <li><?= htmlspecialchars($row[0]) ?></li>
                <?php endwhile; ?>
            </ul>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
